"use client";
import {useEffect,useMemo,useState} from "react";
import {doc,onSnapshot} from "firebase/firestore";
import {db} from "@/lib/firebase";
import {useApp} from "@/components/providers";
import {AMD} from "@/lib/utils";

const PURITIES=[585,750,916,999];
export default function Rates(){
 const {t}=useApp(),[data,setData]=useState<any>(null),[cfg,setCfg]=useState<any>({buyAdjustmentPct:-3,sellAdjustmentPct:4}),[purity,setPurity]=useState(585),[grams,setGrams]=useState(10),[mode,setMode]=useState<"buy"|"sell">("sell");
 useEffect(()=>{const load=()=>fetch("/api/market-rates").then(r=>r.ok?r.json():null).then(setData);load();const u=onSnapshot(doc(db,"settings","pricing"),s=>s.exists()&&setCfg((v:any)=>({...v,...s.data()})));const id=setInterval(load,15*60*1000);return()=>{u();clearInterval(id)}},[]);
 const rows=useMemo(()=>(data?.purities||[]).filter((x:any)=>PURITIES.includes(x.purity)).map((x:any)=>({...x,buy:x.referenceAMD*(1+(cfg[`buy_${x.purity}`]??cfg.buyAdjustmentPct)/100),sell:x.referenceAMD*(1+(cfg[`sell_${x.purity}`]??cfg.sellAdjustmentPct)/100)})),[data,cfg]);
 const sel=rows.find((x:any)=>x.purity===purity); const per=mode==="buy"?(sel?.buy||0):(sel?.sell||0); const estimate=per*grams;
 return <main className="shell page"><div className="page-title"><div className="eyebrow">GOLDMATE RATE CENTER</div><h1>{t.rateTitle}</h1><p>{t.rateText}</p></div><div className="rate-hero"><div className="rate-table panel"><div className="rate-row rate-head"><div>{t.purity}</div><div>{t.marketReference}</div><div>{t.buyPrice}</div><div>{t.sellPrice}</div></div>{rows.map((r:any)=><div className="rate-row" key={r.purity}><div className="purity">{r.purity}</div><div>{AMD.format(r.referenceAMD)}</div><div>{AMD.format(r.buy)}</div><div>{AMD.format(r.sell)}</div></div>)}</div><aside className="panel calculator-card"><div className="eyebrow">{t.calculator}</div><div className="spot-line"><span>{t.marketReference}</span><strong>{data?AMD.format(data.fineGoldAMDPerGram):"—"}</strong><small>999 · {t.perGram}</small></div><div className="calc-fields"><select className="field" value={purity} onChange={e=>setPurity(+e.target.value)}>{PURITIES.map(x=><option key={x}>{x}</option>)}</select><input className="field" type="number" min="0" step=".01" value={grams} onChange={e=>setGrams(+e.target.value)}/><select className="field" value={mode} onChange={e=>setMode(e.target.value as any)}><option value="buy">{t.buyPrice}</option><option value="sell">{t.sellPrice}</option></select></div><div className="calc-result"><span>{t.estimate}</span><strong>{AMD.format(estimate)}</strong></div><div className="rate-meta"><span>{data?.source||"—"}</span><span>{data?.updatedAt?new Date(data.updatedAt).toLocaleString():"—"}</span></div></aside></div><p className="muted rate-note">{t.disclaimer}</p></main>
}
